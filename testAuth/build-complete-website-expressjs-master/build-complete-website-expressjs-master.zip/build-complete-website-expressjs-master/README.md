Nettuts+ Article - Build a Complete MVC Web Site With ExpressJS
======================

The idea is to demonstrate MVC architecture in the context of Express.

## Installation

  - Download the source code
  - Go to *app* directory
  - Run *npm install*
  - Run mongodb daemon
  - Run *node app.js*
  - Open http://localhost:3000 (for the front-end)
  - Open http://localhost:3000/admin (for the control panel)