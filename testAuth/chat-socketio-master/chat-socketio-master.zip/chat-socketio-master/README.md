chat-socketio
=============

Sample Chat application using socketio and backbonejs

Source code for the [Chat Application Using Socket IO](http://www.sitepoint.com/chat-application-using-socket-io/) article on SitePoint.
[Working Demo](http://chatfree.herokuapp.com/)
