Knowing Node
============

This repo holds the code files from my [Knowing Node tutorials on Node.js](http://theholmesoffice.com/category/knowing-node/) and associated technologies.

testpage
--------

Used in [How to build a simple webpage in Node.js](http://theholmesoffice.com/how-to-build-a-simple-webpage-in-node-js/)

testpage-site
-------------

Used in [Creating an MVC framework for our Node.js page – getting ready for scalability](http://theholmesoffice.com/getting-ready-for-scalability-creating-an-mvc-framework-for-our-node-js-page/)

testpage-mongo
--------------

Used in [How to get data from MongoDB into Node.js](http://theholmesoffice.com/how-to-ge-data-from-mongodb-into-node-js/)

testpage-mongoose
-----------------

Used in [Mongoose and Node.js tutorial](http://theholmesoffice.com/mongoose-and-node-js-tutorial/)

testpage-express
-----------------

Used in [Introducing the Express.js framework for node.js](http://theholmesoffice.com/express-js-framework-node-js/)
