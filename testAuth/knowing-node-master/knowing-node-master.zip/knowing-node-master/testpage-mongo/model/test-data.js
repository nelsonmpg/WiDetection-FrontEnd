var thelist = function() {
 var objJson = {"GroupName":"D","count":4,"teams":[{"country":"England"}, {"country":"France"}, {"country":"Sweden"}, {"country":"Ukraine"}]};
 return objJson;
};

exports.teamlist = thelist();

