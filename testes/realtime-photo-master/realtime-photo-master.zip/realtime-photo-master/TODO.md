# TODO

[x] Add Finalist Notice (Who are the finalists?)
[x] Add bets once finalists have been selected (What bets got to be finalists?)
[x] Add Queries after round ends
    [x] Declare Winner when someone reaches 3000.
    [x] Eliminate users with scores le(0)
[ ] Handle when one user is eliminated and the rest are not
[ ] Handle when user disconnects
    [ ] Logout all users of game when one user disconnects
[ ] Add average instead of max