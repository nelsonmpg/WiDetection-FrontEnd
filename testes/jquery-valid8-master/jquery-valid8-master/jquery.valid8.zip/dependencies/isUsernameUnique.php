<?php sleep(1); ?>
{"valid":false}