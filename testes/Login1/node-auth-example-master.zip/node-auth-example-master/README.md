node-auth-example
=================

Authentication Example code with Node.JS, Express, MongoDB, Passport

